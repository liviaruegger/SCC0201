Arquivo zip gerado em: 18/10/2021 21:52:24 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Trabalho 02: Compressão de Áudio